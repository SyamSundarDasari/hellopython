# Arogya-setu-sample-app

1) Used Html and CSS on the client side and Node.js on the server side.
2) Mongodb is used for for storing user data.
3) I have implemented cache and session as well.
4) I can improve error handling by placing much more HTML files on all error handles instead of just an error message.

demo of the project : https://drive.google.com/file/d/1RoJQZN83TTzvlxNGhPMt1S1lLak6gejQ/view?usp=sharing
